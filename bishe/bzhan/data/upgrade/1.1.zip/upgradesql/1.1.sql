insert into zhi_product_client_uplog(`product_id`,`client_id`,`domain`,`source_version`,`to_version`,`create_time`,`remark`) values(
2,1,'www.abc.test','1.2.1','1.2.5',0,'testsql');